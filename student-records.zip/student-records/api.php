<?php
require 'config.php';

// Set session cookie to expire immediately when browser closes
session_set_cookie_params([
  'lifetime' => 0,
  'path' => '/',
  'domain' => '',
  'secure' => false,
  'httponly' => true,
  'samesite' => 'Lax'
]);

session_start();
header('Content-Type: application/json');
function out($d, $c = 200) { http_response_code($c); echo json_encode($d); exit; }

try {
  $pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4", DB_USER, DB_PASS,
    [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]);
} catch (Exception $e) {
  out(['error' => 'Database connection failed. Check config.php and import database.sql in phpMyAdmin.'], 500);
}

$in = json_decode(file_get_contents('php://input'), true) ?: [];
$a = $_GET['action'] ?? '';

// Helper para sa Activity Logs
function logAction($pdo, $username, $action) {
  try {
    $st = $pdo->prepare("INSERT INTO activity_logs (username, action) VALUES (?, ?)");
    $st->execute([$username, $action]);
  } catch (Exception $e) {}
}

if (!$pdo->query("SELECT COUNT(*) FROM users")->fetchColumn()) {
  $pdo->prepare("INSERT INTO users(username,password_hash) VALUES('admin',?)")->execute([password_hash('admin123', PASSWORD_DEFAULT)]);
}

if ($a === 'login') {
  $st = $pdo->prepare("SELECT * FROM users WHERE username=?");
  $st->execute([$in['username'] ?? '']);
  $u = $st->fetch();
  if ($u && password_verify($in['password'] ?? '', $u['password_hash'])) {
    session_regenerate_id(true); 
    $_SESSION['uid'] = $u['id']; 
    $_SESSION['username'] = $u['username'];
    logAction($pdo, $u['username'], "Logged in into the system");
    out(['ok' => true, 'username' => $u['username']]);
  }
  out(['error' => 'Invalid username or password'], 401);
}

if ($a === 'signup') {
  $username = trim($in['username'] ?? '');
  $password = $in['password'] ?? '';
  if ($username === '' || $password === '') out(['error' => 'Username and password are required.'], 422);
  
  $st = $pdo->prepare("SELECT COUNT(*) FROM users WHERE username = ?");
  $st->execute([$username]);
  if ($st->fetchColumn() > 0) out(['error' => 'Username is already taken.'], 409);
  
  try {
    $hash = password_hash($password, PASSWORD_DEFAULT);
    $st = $pdo->prepare("INSERT INTO users (username, password_hash) VALUES (?, ?)");
    $st->execute([$username, $hash]);
    logAction($pdo, $username, "Registered a new account");
    out(['ok' => true]);
  } catch (Exception $e) {
    out(['error' => 'Could not register user.'], 500);
  }
}

if ($a === 'session') {
  if (isset($_SESSION['uid'])) {
    $st = $pdo->prepare("SELECT username FROM users WHERE id=?");
    $st->execute([$_SESSION['uid']]);
    $u = $st->fetch();
    out(['auth' => true, 'username' => $u['username'] ?? 'User']);
  } else {
    out(['auth' => false]);
  }
}

if ($a === 'logout') { 
  if (isset($_SESSION['username'])) logAction($pdo, $_SESSION['username'], "Logged out");
  session_destroy(); 
  setcookie(session_name(), '', time() - 3600, '/');
  out(['ok' => true]); 
}

if (!isset($_SESSION['uid'])) out(['error' => 'Not logged in'], 401);

// Change Password
if ($a === 'change_password') {
  $old = $in['old_password'] ?? '';
  $new = $in['new_password'] ?? '';
  if ($old === '' || $new === '') out(['error' => 'All fields are required.'], 422);
  
  $st = $pdo->prepare("SELECT * FROM users WHERE id=?");
  $st->execute([$_SESSION['uid']]);
  $u = $st->fetch();
  if (!$u || !password_verify($old, $u['password_hash'])) {
    out(['error' => 'Incorrect current password.'], 400);
  }
  
  $hash = password_hash($new, PASSWORD_DEFAULT);
  $pdo->prepare("UPDATE users SET password_hash=? WHERE id=?")->execute([$hash, $_SESSION['uid']]);
  logAction($pdo, $_SESSION['username'], "Changed password");
  out(['ok' => true]);
}

// Fetch Activity Logs
if ($a === 'logs') {
  out($pdo->query("SELECT * FROM activity_logs ORDER BY created_at DESC LIMIT 50")->fetchAll());
}

if ($a === 'list') {
  out($pdo->query("SELECT student_id AS id, name, email, phone, course, year_level AS year, gender, status,
    gpa, address, enrolled FROM students ORDER BY name")->fetchAll());
}

if ($a === 'save') {
  $name = trim($in['name'] ?? ''); $email = trim($in['email'] ?? ''); $gpa = $in['gpa'] ?? '';
  if ($name === '') out(['error' => 'Name is required.'], 422);
  if (!filter_var($email, FILTER_VALIDATE_EMAIL)) out(['error' => 'Enter a valid email address.'], 422);
  if (!is_numeric($gpa) || $gpa < 0 || $gpa > 4) out(['error' => 'GPA must be between 0 and 4.0.'], 422);
  if (!in_array($in['status'] ?? '', ['Active', 'Graduated', 'Inactive'])) out(['error' => 'Invalid status.'], 422);
  if (!in_array($in['gender'] ?? '', ['Female', 'Male', 'Other'])) out(['error' => 'Invalid gender.'], 422);
  $enr = ($in['enrolled'] ?? '') ?: null;
  $vals = [$name, $email, trim($in['phone'] ?? ''), trim($in['course'] ?? ''), (int)($in['year'] ?? 1),
           $in['gender'], $in['status'], $gpa, trim($in['address'] ?? ''), $enr];
  try {
    if (!empty($in['id'])) {
      $pdo->prepare("UPDATE students SET name=?,email=?,phone=?,course=?,year_level=?,gender=?,status=?,gpa=?,address=?,enrolled=? WHERE student_id=?")
          ->execute([...$vals, $in['id']]);
      logAction($pdo, $_SESSION['username'] ?? 'System', "Updated student: $name ({$in['id']})");
      out(['ok' => true, 'id' => $in['id']]);
    }
    $n = (int)$pdo->query("SELECT COALESCE(MAX(CAST(SUBSTRING(student_id,5) AS UNSIGNED)),0) FROM students")->fetchColumn() + 1;
    $id = 'STU-' . str_pad($n, 4, '0', STR_PAD_LEFT);
    $pdo->prepare("INSERT INTO students(name,email,phone,course,year_level,gender,status,gpa,address,enrolled,student_id) VALUES(?,?,?,?,?,?,?,?,?,?,?)")
        ->execute([...$vals, $id]);
    logAction($pdo, $_SESSION['username'] ?? 'System', "Added new student: $name ($id)");
    out(['ok' => true, 'id' => $id]);
  } catch (PDOException $e) {
    if (($e->errorInfo[1] ?? 0) == 1062) out(['error' => 'That email is already registered.'], 409);
    out(['error' => 'Could not save the record.'], 500);
  }
}

if ($a === 'delete') {
  $id = $in['id'] ?? '';
  $st = $pdo->prepare("SELECT name FROM students WHERE student_id=?");
  $st->execute([$id]);
  $s = $st->fetch();
  $pdo->prepare("DELETE FROM students WHERE student_id=?")->execute([$id]);
  logAction($pdo, $_SESSION['username'] ?? 'System', "Deleted student: " . ($s['name'] ?? $id));
  out(['ok' => true]);
}
out(['error' => 'Unknown action'], 400);