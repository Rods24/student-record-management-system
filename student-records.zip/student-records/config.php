<?php
// XAMPP / WAMP defaults. Change these if your MySQL uses a different user or password.
define('DB_HOST', 'localhost');
define('DB_NAME', 'student_records');
define('DB_USER', 'root');
define('DB_PASS', '');
